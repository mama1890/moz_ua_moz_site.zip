document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('appointment-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const formData = new FormData(form);
      const appointment = {
        patientName: formData.get('patientName'),
        doctorId: formData.get('doctorId'),
        datetime: formData.get('datetime'),
      };
      const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
      appointments.push(appointment);
      localStorage.setItem('appointments', JSON.stringify(appointments));
      alert('Запис створено!');
      form.reset();
    });
  }

  const appointmentsContainer = document.getElementById('appointments');
  if (appointmentsContainer) {
    const doctorId = localStorage.getItem('loggedInDoctor');
    const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
    const filtered = appointments.filter(a => a.doctorId === doctorId);
    if (filtered.length === 0) {
      appointmentsContainer.innerHTML = '<p>Записів немає</p>';
    } else {
      appointmentsContainer.innerHTML = '<h2>Ваші записи:</h2>' + filtered.map(a => `
        <div><strong>${a.patientName}</strong> — ${new Date(a.datetime).toLocaleString()}</div>
      `).join('');
    }
  }
});